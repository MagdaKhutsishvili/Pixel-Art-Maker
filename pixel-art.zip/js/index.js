
function makeGrid() {

	let tableHeight, tableWidth, color = 0;
	var canvas = $('#pixelCanvas');
	canvas.find('*').remove();
	
	
	tableHeight = $('#sizePicker').children('input').first().val();

	tableWidth = $('#inputWidth').val();
	
	if(tableHeight > 0 && tableWidth > 0){
		for(var h = 0; h < tableHeight; h++){
			canvas.append('<tr></tr>');	
			for(var w = 0; w < tableWidth; w++){
				canvas.children('tr').eq(h).append('<td></td>');
			}
		}
	}else{
		console.log("Too low dimension!");
	}
}

function getColor(){
	var color = "";
	color = $('#colorPicker').val();

	return color;
}

$('#submit').on('click',function(evt){
	evt.preventDefault();
	$(makeGrid());	
});

$('#pixelCanvas').on('click','td',function(){
	$(this).attr('style','background-color:' + getColor());
});